import "./App.css";
import Main from "./components/Main";
import Task from "./components/Task";

function App() {
  return (
    <div className="App">
      <Task />
      {/* <Main/> */}
    </div>
  );
}

export default App;
